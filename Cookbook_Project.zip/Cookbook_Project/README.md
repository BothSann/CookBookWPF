# CookbookWPF
Cookbook created in WPF.
Adding, editing and deleting recipes.
Data stored in local database using EntityFramework and SQLite.
Made using MVVM architecture pattern by following SingletonSean tutorial: https://www.youtube.com/watch?v=54ZmhbpjBmg
