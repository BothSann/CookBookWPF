﻿namespace CookbookWPF
{
    internal class RecipeStore
    {
    }
}